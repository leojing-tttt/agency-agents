# 功能列表（打标 + 管理）

## 0. 本地管理 UI（前后端）

- 后端：FastAPI（`image_tagger.server`）
- 前端：`web/index.html` + CSS/JS（离线可开，无 CDN）
- 启动：`python -m image_tagger.cli serve --port 8787`
- 页面：维度管理 / 映射管理 / 校验
- 不要求先选品牌产品即可检查词表

## 1. 维度管理（标签类型管理）

- 查看所有维度及其枚举（id + 中文名）
- 新增枚举（例如渠道增加「永辉」）
- 删除枚举（必填维度至少保留 1 个）
- 词表版本号（`taxonomy.version`）
- 开放字段配置：`scene_tags`、`ocr_text` 上限
- 场景同义词归并（爬山→登山）
- **不管理**产品品牌维度（产品可稍后选；打标命令也支持占位产品）

数据文件：`data/taxonomy.json`

## 2. 映射表管理（图片类型细类枚举 → 汇总大类）

- 查看汇总大类列表
- 查看 / 修改「细类枚举 → 汇总大类」
- 与 `image_type` 维度交叉校验：
  - 每个细类枚举必须有映射
  - 不能映射到不存在的大类
  - 不能残留词表里已删除的细类枚举
- 映射版本号（`mapping.version`）

数据文件：`data/image_type_category_map.json`

## 3. 打标执行

- 强制先带 `product_id` / `product_name`（及可选 knowledge_id）
- 扫描 inbox 图片批处理
- **单次**本地视觉模型调用，输出全部封闭维度
- 程序校验枚举；非法或低置信度 → `needs_review`
- 自动附加 `image_type_category`（来自映射表，非模型输出）
- 导出 JSONL + 待审 CSV
- 文件哈希去重字段（`image_sha256`，便于后续跳过）

## 4. 后续可加（本切片未做）

- 上传打标网页（选图 / 选产品）
- 人审通过后写回「已确认标签」
- 失败维度二次补打
- 多品牌 pack 切换
- 与内容 agent / 配图推荐对接
